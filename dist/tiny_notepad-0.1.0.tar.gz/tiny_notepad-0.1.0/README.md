# Tiny Notepad

A lightweight notepad with local Ollama AI integration.

## Install

```bash
pip install tiny_notepad

tiny_notepad
```


